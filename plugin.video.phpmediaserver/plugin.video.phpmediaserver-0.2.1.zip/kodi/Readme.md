# PHPMEDIASERVER

Example getting lists from phpmediaserver

License: [GPL v.3](http://www.gnu.org/copyleft/gpl.html)
